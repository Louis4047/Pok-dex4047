const pokedex = document.getElementById("pokedex");
const searchInput = document.getElementById("search");
const typeFilter = document.getElementById("typeFilter");

let allPokemon = [];

const fetchPokemon = async () => {
  for (let i = 1; i <= 20; i++) {
    const res = await fetch(`https://pokeapi.co/api/v2/pokemon/${i}`);
    const data = await res.json();
    allPokemon.push(data);
    displayPokemon(data);
    updateTypeFilter(data);
  }
};

const displayPokemon = (pokemon) => {
  const card = document.createElement("div");
  card.classList.add("pokemon");

  const types = pokemon.types.map(t => `<span class="type">${t.type.name}</span>`).join("");

  const stats = pokemon.stats.map(stat =>
    `<div class="stat"><strong>${stat.stat.name}:</strong> ${stat.base_stat}</div>`
  ).join("");

  card.innerHTML = `
    <h2>${pokemon.name[0].toUpperCase() + pokemon.name.slice(1)}</h2>
    <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}">
    <div>${types}</div>
    <div class="stats">${stats}</div>
  `;

  pokedex.appendChild(card);
};

const updateTypeFilter = (pokemon) => {
  pokemon.types.forEach(t => {
    if (!Array.from(typeFilter.options).some(opt => opt.value === t.type.name)) {
      const opt = document.createElement("option");
      opt.value = t.type.name;
      opt.textContent = t.type.name;
      typeFilter.appendChild(opt);
    }
  });
};

const filterDisplay = () => {
  const searchVal = searchInput.value.toLowerCase();
  const typeVal = typeFilter.value;

  pokedex.innerHTML = "";
  allPokemon.forEach(pokemon => {
    const nameMatch = pokemon.name.includes(searchVal);
    const typeMatch = typeVal === "all" || pokemon.types.some(t => t.type.name === typeVal);

    if (nameMatch && typeMatch) {
      displayPokemon(pokemon);
    }
  });
};

searchInput.addEventListener("input", filterDisplay);
typeFilter.addEventListener("change", filterDisplay);

fetchPokemon();